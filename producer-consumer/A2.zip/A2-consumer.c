#include "A2.h"
void *consumer()
{
    int consumed = 0;
    int i, id, pid;
    pid = getpid();
    while (1)
    // for (i = 1; i <= N; i++)
    {
        sem_wait(Sc); // decrement Sc

        // read id of filled position to consume
        sem_wait(filled_lock);
        id = filled->head;
        dequeue(filled, 1);
        sem_post(filled_lock);

        // consume
        sem_wait(free_lock);
        enqueue(empty, id, 0); // add id at the end of empty indices queue
        consumed++;
        printf("[consumer id:%d] Consumed at index %d.\n", pid, id);
        sem_post(free_lock);

        sleep(rand() % 3 + 1);
        sem_post(Sp);
    }
    printf("[consumer id:%d] Finished. Total consumed: %d.\n", pid, consumed);
}