#include "A2.h"
void *producer()
{
    int i;
    int value, id, pid;
    int produced = 0;
    pid = getpid();
    while (1)
    // for (i = 1; i <= N; i++)
    {
        value = rand() % 100; // some random value
        sem_wait(Sp);         // decrement Sp

        // read free position value & pop it from queue
        sem_wait(free_lock);
        id = empty->head;
        dequeue(empty, 0);
        sem_post(free_lock);

        // produce
        sem_wait(filled_lock);  // lock
        buffer[id] = value;     // fill buffer at id
        enqueue(filled, id, 1); // add to filled positions
        produced++;
        printf("[producer id:%d] Produced at index %d.\n", pid, id);
        sem_post(filled_lock); // unlock

        sleep(1 + rand() % 3); // delay randomly
        sem_post(Sc);          // increment Sc
    }
    printf("[producer id:%d] Finished. Total produced: %d.\n", pid, produced);
}
